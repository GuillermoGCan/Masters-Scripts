rm(list=ls())

setwd("Inserta aquí tu directorio de trabajo donde tengas los archivos descargados")


library("sf") # librería para cargar shapefiles

agebs <- read_sf(dsn="./marcogeoestadistico2020/19_nuevoleon/conjunto_de_datos", layer="19a")
head(agebs) ## Lee el archivo cartográfico

tabla <- read.csv("./agebs2021/agebs_2021.csv", encoding ="UTF -8", na.strings = "*",
                  stringsAsFactors = FALSE) #Lee la tabla de resultados

## Genera un campo en comun con el shapefile para unir las dos bases de datos:

tabla$MUN <- ifelse(nchar(tabla$MUN)==1, paste("00", tabla$MUN, sep=""), 
                    ifelse(nchar(tabla$MUN)==2, paste("0", tabla$MUN, sep=""),
                           tabla$MUN))

tabla$LOC <- ifelse(nchar(tabla$LOC)==1, paste("000", tabla$LOC, sep=""), 
                    ifelse(nchar(tabla$LOC)==2, paste("00", tabla$LOC, sep=""),
                           ifelse(nchar(tabla$LOC)==3, paste("0", tabla$LOC, sep=""),
                           tabla$LOC)))

tabla$AGEB <- ifelse(nchar(tabla$AGEB)==1, paste("000", tabla$AGEB, sep=""), 
                    ifelse(nchar(tabla$AGEB)==2, paste("00", tabla$AGEB, sep=""),
                           ifelse(nchar(tabla$AGEB)==3, paste("0", tabla$AGEB, sep=""),
                                  tabla$AGEB)))
# Genera el campo CVEGEO
tabla$CVEGEO <- paste(tabla$ENTIDAD, tabla$MUN, tabla$LOC, tabla$AGEB, sep="")
head(tabla)


table(tabla$CVEGEO %in% agebs$CVEGEO)
table(agebs$CVEGEO %in% tabla$CVEGEO)

# Une los dos archivos. El objeto agebs_urbanas tiene la cartografia de agebs y todos los
# datos del censo del 2020.
agebs_urbanas <- merge(x=agebs, y=tabla, by="CVEGEO")
class(agebs_urbanas) # Revisa el tipo de objeto: sf es un objeto espacial con coordenadas

# Extrae la tabla a un data frame que no sea un objeto espacial
# Posiblemente tengas que instalar la librería dplyr.
df <- dplyr::select(as.data.frame(agebs_urbanas), -geometry)
